Hi Visual Studio 2022 Developer,

In this module, we started with a new .NET project, so there is nothing in this "before" folder.

Please look in the "after" folder to find the project that was created in this module.

Thank you,
Thomas Claudius Huber 
> www.thomasclaudiushuber.com
> @thomasclaudiush
