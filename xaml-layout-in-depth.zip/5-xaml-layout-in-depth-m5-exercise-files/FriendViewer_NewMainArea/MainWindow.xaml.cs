﻿using FriendViewer.DataProvider;
using FriendViewer.ViewModel;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using FriendViewer.Extensions;

namespace FriendViewer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void MainArea_MouseEnter(object sender, MouseEventArgs e)
        {
            if (!navigationControl.IsPinned)
            {
                GeneralTransform generalTransform = this.TransformToVisual(navigationGrid);
                Point point = generalTransform.Transform(new Point());

                point.X += navigationTransform.X;
                point.X -= navigationColumn.ActualWidth;
                point.Y = 0;
                navigationTransform.AnimateTo(point);
            }
        }

        private void Button_MouseEnter(object sender, MouseEventArgs e)
        {
            navigationTransform.AnimateTo(new Point());
        }

        private void navigationControl_IsPinnedChanged(object sender, System.EventArgs e)
        {
            if(navigationControl.IsPinned)
            {
                if(!mainAreaGrid.ColumnDefinitions.Contains(columnToAddOrRemove))
                {
                    mainAreaGrid.ColumnDefinitions.Insert(0,columnToAddOrRemove);
                }
                navigationButton.Visibility = Visibility.Collapsed;
            }
            else
            {
                if (mainAreaGrid.ColumnDefinitions.Contains(columnToAddOrRemove))
                {
                    mainAreaGrid.ColumnDefinitions.Remove(columnToAddOrRemove);
                }
                navigationButton.Visibility = Visibility.Visible;
            }
        }
    }
}
