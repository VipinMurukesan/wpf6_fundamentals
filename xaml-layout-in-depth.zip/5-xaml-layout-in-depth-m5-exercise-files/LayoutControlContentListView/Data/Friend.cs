﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LayoutControlContent.Data
{
    public class Friend
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
