﻿using PanelOfItemsControl.Data;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PanelOfItemsControl.ViewModel
{
    public class MainViewModel
    {
        public MainViewModel()
        {
            Friends = new ObservableCollection<Friend>();
            LoadData();
        }

        public ObservableCollection<Friend> Friends { get; set; }

        private void LoadData()
        {
            Friends.Add(new Friend { FirstName = "Thomas", LastName = "Huber" });
            Friends.Add(new Friend { FirstName = "Julia", LastName = "Huber" });
            Friends.Add(new Friend { FirstName = "Simon", LastName = "Hiener" });
            Friends.Add(new Friend { FirstName = "Andreas", LastName = "Werne" });
            Friends.Add(new Friend { FirstName = "Sandra", LastName = "Matt" });
            Friends.Add(new Friend { FirstName = "Marcel", LastName = "Zipper" });
            Friends.Add(new Friend { FirstName = "Kerstin", LastName = "Ganz" });
            Friends.Add(new Friend { FirstName = "Sven", LastName = "Pfau" });
            Friends.Add(new Friend { FirstName = "Chrissi", LastName = "Egin" });
            Friends.Add(new Friend { FirstName = "Martin", LastName = "Bauer" });
        }
    }
}
