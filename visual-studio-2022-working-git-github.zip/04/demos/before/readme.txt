Hi Visual Studio 2022 Developer,

This module starts where the previous module ended. 

This means that you find the starter demo for this module in the previous module's "after"-folder.

Thank you,
Thomas Claudius Huber 
> www.thomasclaudiushuber.com
> @thomasclaudiush
