﻿namespace WiredBrainCoffee.ShopInfoTool.Model;

public record CoffeeShop(string City, int CupsInStock);
