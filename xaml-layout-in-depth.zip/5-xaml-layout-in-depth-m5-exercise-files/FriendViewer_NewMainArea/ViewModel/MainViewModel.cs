﻿using FriendViewer.Commands;
using FriendViewer.DataProvider;
using FriendViewer.Model;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;

namespace FriendViewer.ViewModel
{
    public class MainViewModel : Observable
    {
        private readonly IFriendDataProvider _dataProvider;
        private Friend _selectedFriend;

        public MainViewModel(IFriendDataProvider dataProvider)
        {
            _dataProvider = dataProvider;
            Friends = new ObservableCollection<Friend>();
            MainAreaFriends = new ObservableCollection<Friend>();
            CloseMainAreaFriendCommand = new DelegateCommand(OnCloseMainAreaFriendExecuted);

            LoadData();
        }

        private void LoadData()
        {
            var friends = _dataProvider.LoadFriends();
            foreach (var friend in friends)
            {
                Friends.Add(friend);
            }

            SelectedFriend = Friends.Count > 0 ? Friends.First() : null;
        }

        public ObservableCollection<Friend> Friends { get; set; }

        /// <summary>
        /// Contains just the friends displayed in the main area.
        /// This will be a subset of the Friends-Property
        /// </summary>
        public ObservableCollection<Friend> MainAreaFriends { get; set; }

        public Friend SelectedFriend
        {
            get { return _selectedFriend; }
            set
            {
                _selectedFriend = value;
                OnPropertyChanged();
                if (_selectedFriend != null)
                {
                    if (MainAreaFriends.Contains(_selectedFriend))
                    {
                        MainAreaFriends.Move(MainAreaFriends.IndexOf(_selectedFriend), 0);
                    }
                    else
                    {
                        MainAreaFriends.Insert(0, _selectedFriend);
                    }
                }
            }
        }

        public ICommand CloseMainAreaFriendCommand { get; private set; }

        private void OnCloseMainAreaFriendExecuted(object obj)
        {
            var friend = obj as Friend;
            if (friend != null && MainAreaFriends.Contains(friend))
            {
                MainAreaFriends.Remove(friend);
                if (SelectedFriend == friend)
                {
                    SelectedFriend = null;
                }
            }
        }
    }
}
