﻿using System.Windows.Controls;

namespace FriendViewer.Controls
{
    /// <summary>
    /// Interaction logic for FriendControl.xaml
    /// </summary>
    public partial class FriendControl : UserControl
    {
        public FriendControl()
        {
            InitializeComponent();
        }
    }
}
