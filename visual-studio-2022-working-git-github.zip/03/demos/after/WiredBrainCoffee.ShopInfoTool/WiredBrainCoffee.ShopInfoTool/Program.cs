﻿Console.WriteLine("-------------------------------------");
Console.WriteLine(" Wired Brain Coffee - Shop Info Tool ");
Console.WriteLine("-------------------------------------");

Console.ReadLine();